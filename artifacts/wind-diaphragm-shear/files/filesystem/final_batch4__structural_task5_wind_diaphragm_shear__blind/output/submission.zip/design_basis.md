# Design Basis — Building A2 Lateral Package

| item | value | source |
|---|---|---|
| Kzt topographic factor used | 1.19 | TS-2026-02 |
| Ke ground elevation factor used | 1.00 | EOR criteria |
| q_h_psf velocity pressure at mean roof height | 25.0 | WT-2026-07 |
| screen_wall_top_ft top elevation of the mechanical screen wall | 36.0 | SR-2026-118 5.2 |
| asbuilt_opening_panel panel mark(s) whose as-built opening is not on the 2024 precast shop drawing | N-series | SR-2026-118 |
| asd_combination the load combination the reported loads are on | 0.6W | EOR criteria |
| omega_d the deck catalogue's safety factor for ASD capacity | 2.0 | CDS-B36 |
| analysis_method the diaphragm idealisation used | finite element shear panel | EOR criteria |
| mesh_level the refinement level the reported quantities are taken at | 3 | convergence |

| line | governing scenario |
|---|---|
| S | W05 |
| N | W01 |
| E | W03 |
| W | W01 |

## Conflicts resolved
Kzt 1.00 (2024 Rev0, superseded) vs 1.19 (TS-2026-02): 1.19 governs.
Screen wall top 31 ft (2024 panel schedule) vs 36 ft (SR-2026-118): 36 ft governs.
2024 rectangle geometry vs 2026 federated model / roof scan: as-built model governs.
