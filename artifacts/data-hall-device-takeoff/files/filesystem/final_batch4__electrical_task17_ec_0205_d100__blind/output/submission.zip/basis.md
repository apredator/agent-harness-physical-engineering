# Basis of Takeoff — Data Hall ec_0205_d100

## Counting convention
Devices counted symbol-by-symbol from the device plans (E-201..E-204, E-101, E-211, enlarged E-231..E-233) per E-002 schedule; legend E-001 is the only authority for symbol meaning. Per criteria manual §5 (E-22).

## Governing issue
Latest addendum governs where it postdates a sheet revision (criteria manual).

## Condition split
- E-002 sets (EMERGENCY, IG, CEILING, ACCESS-FLOOR) take precedence.
- DAMP: device inside area hatched DAMP on A-102.
- Wall condition: construction of nearest wall centreline on A-102.
- Keyed-note-only devices: wall named by note, or DRY-STUD.
- Duct smoke detector carried under CEILING.

## Assembly per condition
Per Division 26 20 00 spec and manufacturer catalogue; each device requires box + ring/cover/accessory per condition.

## Spare-stock and carton method
Purchase quantity = ceil((required × 1.05) / carton_qty) × carton_qty, per E-18/E-19.

## While-in-use hood
Specification requires while-in-use hood for R5; catalogue carries none — stated here, no line carried.

## Basket total
See bom.csv.

## Unresolved symbols
Symbols on plans not present in legend E-001 are not scheduled devices and carry no quantity; listed here for resolution.
