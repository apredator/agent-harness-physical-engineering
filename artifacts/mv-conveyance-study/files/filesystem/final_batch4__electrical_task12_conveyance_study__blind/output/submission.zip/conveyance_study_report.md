# Pacific Crest Space Force Annex

Conveyance study for the 13.8 kV site distribution, solicitation FA4610-26-R-0031.

## Recommendation summary

Each item was evaluated against every conveyance type required by RFP 01 11 00 Section 1.4. The most cost-effective admissible design for each item is listed in the workbook Items sheet.

See conveyance_study.xlsx for Alternatives, Takeoff, Segments, Structures, Pulls, LaborRates, EquipmentRates, Markups, Register and Findings.
