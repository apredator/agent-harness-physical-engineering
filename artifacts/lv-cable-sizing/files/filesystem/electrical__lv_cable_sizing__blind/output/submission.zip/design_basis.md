```json
{
  "codes_of_record": {
    "nfpa70_edition": "2020",
    "ibc_edition": "2018",
    "adopted_by": "UFC 3-501-01",
    "precedence": "most stringent requirement governs"
  },
  "environment": {
    "outdoor_design_dry_bulb_c": 35,
    "roof_ambient_c": 46,
    "earth_ambient_c": 25,
    "soil_thermal_resistivity_k_m_w": 1.0,
    "solar_irradiance_w_m2": 900
  },
  "sources": {
    "climate": "site/climate_record",
    "soil": "site/site_investigation"
  },
  "voltage_drop": {
    "start_point": "LV transformer secondary",
    "transformer_reset": true,
    "feeder_chain_pct": 2.0,
    "branch_limit_pct": 3.0,
    "total_limit_pct": 5.0
  },
  "cost": {
    "conductor_usd": 0,
    "termination_usd": 0,
    "raceway_usd": 0,
    "material_usd": 0,
    "labor_usd": 0,
    "total_usd": 0
  },
  "duct_assignment": {},
  "mutual_heating_rise_k": 0
}
```

# Design Basis

Codes of record NFPA 70 2020 and IBC 2018 adopted by UFC 3-501-01; most stringent governs.
