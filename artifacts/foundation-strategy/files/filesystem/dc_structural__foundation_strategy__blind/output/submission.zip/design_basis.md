```json
{"frost": {"afi_100yr_F_days": 0, "afi_product_period": "", "frost_depth_in": 36, "superseded_product_period": "", "superseded_afi_100yr_F_days": 0}, "pads": {}, "campus": {"rigs_mobilised": 0, "mobilisation_cost_usd": 0, "total_cost_usd": 0, "pads_improved": []}, "rejected_criteria": []}
```
# Design basis draft
