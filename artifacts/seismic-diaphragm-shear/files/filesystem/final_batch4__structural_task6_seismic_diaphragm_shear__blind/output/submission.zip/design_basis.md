# Building B - seismic diaphragm and shear wall design basis

Design format: <LRFD or ASD>

## 1. Seismic basis

## 2. Seismic force-resisting system

<the system you selected, its R, Omega_0 and Cd, the clause that permits it in this seismic design category at this height, and why it is the cost-efficient choice>

## 3. As-built geometry

<every conflict you found between the documents and which reading you took>

## 4. Analysis

## 5. Diaphragm and wall forces

## 6. Wall anchorage and the parapet cantilever

## 7. Governing constraint per wall line

## 8. Cost

## 9. Alternatives rejected
